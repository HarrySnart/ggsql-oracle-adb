---
name: ggsql-oracle-skill
description: ggsql Oracle workflows that validate SQL through the SQLcl MCP server before rendering visualisations with ggsqlOracle in Python. Use when you need to confirm Oracle SQL, run ggsql VISUALISE clauses, or set up the supporting Python environment.
---

# ggsql Oracle Skill

Use this skill when you must take Oracle SQL that has already been vetted with SQLcl and feed it into the Python `ggsqlOracle` helper to produce Altair visualisations.

## Quick Start

1. **Validate SQL in SQLcl** – Launch the SQLcl MCP server skill, list or confirm connections, and run the target SQL until the result set is correct. See [SQLcl MCP Workflow](references/sqlcl-mcp-workflow.md).
2. **Prepare Python runtime** – Activate an existing virtual environment or create one with `python3 -m venv .venv` and `pip install -r assets/requirements.txt`. Guidance lives in [Oracle Python Environment Checklist](references/oracle-environment.md). If macOS blocks writes inside this skill (`operation not permitted`), clear the quarantine attribute with `xattr -d com.apple.provenance <path>` and re-run the command.
3. **Execute with ggsqlOracle** – Call `ggsqlOracle.sync(sql=...)` with the exact SQL you validated in SQLcl. The class stores the dataframe, last SQL, and latest ggsql query.
4. **Visualise** – Pass a `VISUALISE` clause string into `ggsqlOracle.plot(...)`. Refer to [ggsql Visualise Cheatsheet](references/ggsql-visualise-cheatsheet.md) for syntax reminders.
5. **Persist output** – Use `ggsqlOracle.save("chart.html")` or export PNG/SVG after installing `vl-convert-python` (already in requirements).

## Workflow Details

### 1. Confirm the SQL via SQLcl MCP

- Start with the SQLcl MCP server so you can enumerate available Oracle aliases and run smoke queries before touching Python.
- Use `SHOW CONNECTION` to verify your session. If aliases are configured, list them (`ALIAS LIST` or a dedicated MCP action) and connect with the right wallet/DSN information.
- Iterate on the SQL until column names, ordering, and row counts match the expectations of your ggsql visualisation. Copy that exact text when you move to Python.

### 2. Set Up or Reuse the Environment

- Activate an existing `.venv` if present (`source .venv/bin/activate`). If none exists, create one and install `assets/requirements.txt` for Altair, ggsql, Polars, and oracledb.
- Confirm Oracle Instant Client or wallet paths if you rely on thick mode. The environment checklist reference covers required variables and verification steps.

### 3. Work with `ggsqlOracle`

- Construct the helper with either an Oracle connection or a pool. Pools must expose `.acquire()`.
- Run `sync(sql, arraysize=1000)` to materialise results as a Polars DataFrame. Column names are lowercased to match ggsql expectations.
- Retain the returned dataframe for quick inspection (`client.df`) and review stored metadata via `client.last_sql` and `client.last_ggsql`.

### 4. Build the Visualisation

- Compose ggsql queries that align with the fetched columns. Use the cheatsheet to recall `VISUALISE`, `DRAW`, `SCALE`, `FACET`, and `LABEL` options.
- Validate `VISUALISE` clauses with `ggsql.validate(...)` if you need static checking before rendering.
- Remember that `ggsqlOracle.plot` produces an Altair chart; call `display()` in notebooks or `save()` when running headless.

### 5. Example Run

- Adapt `examples/oracle_violin.py` with local credentials. The script demonstrates loading a JSON config, validating SQL beforehand, calling `sync`, plotting a violin chart, and saving HTML output.
- Always test the SQL fragment in SQLcl first, then paste it into the script so that `ggsqlOracle.sync` receives known-good SQL.

## Troubleshooting Tips

- **Missing columns** – Ensure your SQL returns every aesthetic used in `VISUALISE`. Recheck with SQLcl before modifying Python.
- **Connection errors** – Verify environment variables and wallet paths, then retry the SQLcl session to ensure Oracle networking works outside Python.
- **Slow queries** – Adjust the `arraysize` parameter or stage data in temporary tables via SQLcl before running ggsql.
- **Export issues** – If PNG/SVG export fails, confirm `vl-convert-python` is installed and accessible within the active virtual environment.

## Bundled Resources

- `references/sqlcl-mcp-workflow.md` – Detailed steps for working inside SQLcl MCP.
- `references/oracle-environment.md` – Environment prep and verification checklist.
- `references/ggsql-visualise-cheatsheet.md` – Compact ggsql clause summary from the project documentation.
- `examples/oracle_violin.py` – End-to-end Python example ready for credential injection.
- `assets/requirements.txt` – Dependency lockfile to stand up the Python environment quickly.
