"""Example ggsqlOracle workflow.

Edit the `CONFIG_PATH` JSON file to supply Oracle credentials and wallet details.
Run after testing the SQL statement in SQLcl.
"""

from __future__ import annotations

import json
from pathlib import Path

import oracledb

from ggsqlOracle import ggsqlOracle

CONFIG_PATH = Path("./config.json")

SQL_STATEMENT = """
SELECT *
FROM HMEQ
""".strip()

GGSQL_QUERY = """
VISUALISE reason AS x, loan AS y
DRAW violin
LABEL title => 'Violin Plot from Oracle Table'
""".strip()

def load_credentials(config_path: Path) -> dict[str, str]:
    data = json.loads(config_path.read_text())
    # Expect the JSON to contain a single row of connection details.
    return {key: values[0] for key, values in data.items()}

def main() -> None:
    creds = load_credentials(CONFIG_PATH)

    connection = oracledb.connect(
        user=creds["user"],
        password=creds["password"],
        dsn=creds["dsn"],
        config_dir=creds["config_dir"],
        wallet_location=creds["wallet_dir"],
        wallet_password=creds["wallet"],
    )

    client = ggsqlOracle(connection)
    df = client.sync(sql=SQL_STATEMENT)
    print(f"Fetched {len(df)} rows")

    chart = client.plot(GGSQL_QUERY)
    chart.save("./violin_plot.html")
    print("Saved Altair visualization to violin_plot.html")

if __name__ == "__main__":
    main()
