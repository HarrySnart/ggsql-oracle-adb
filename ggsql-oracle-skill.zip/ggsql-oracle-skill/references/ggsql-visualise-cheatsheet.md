# ggsql Visualise Cheatsheet

Summaries below come from the ggsql project documentation (`CLAUDE.md`). Use this when you need a quick reminder of valid clauses while authoring `VISUALISE` sections.

## Query Structure

```
SELECT ...
VISUALISE [global mapping]
DRAW ...
SCALE ...
FACET ...
PROJECT ...
LABEL ...
```

- `VISUALISE` separates SQL data retrieval from visual encoding.
- `VISUALISE FROM <source>` injects `SELECT * FROM <source>` automatically.
- Global mappings defined on `VISUALISE` apply to all subsequent layers.

## Global Mapping Options

| Syntax | Meaning |
| --- | --- |
| `VISUALISE` | No global mappings. |
| `VISUALISE *` | Wildcard mapping; ggsql matches columns to same-named aesthetics. |
| `VISUALISE col AS aesthetic` | Explicit mapping (e.g., `date AS x`). |
| `VISUALISE x, y` | Implicit mapping; column name matches target aesthetic. |

## DRAW Layers

```
DRAW <geom>
  MAPPING col AS aesthetic, ...
  SETTING param => value, ...
  PARTITION BY col, ...
  FILTER expression
```

- `geom`: `line`, `bar`, `point`, `area`, `violin`, etc.
- Use `MAPPING` for data-driven aesthetics and `SETTING` for literal parameters.
- `PARTITION BY` groups rows for lines/paths without changing color.
- `FILTER` applies record-level filters per layer.
- `PLACE` layers (annotations) accept only `SETTING` values.

## SCALE Clause

```
SCALE [TYPE] aesthetic [FROM (...)] [TO (...|palette)] [VIA transform]
  SETTING option => value
```

- Types: `CONTINUOUS`, `DISCRETE`, `BINNED`, `DATE`, `DATETIME`.
- Use `SCALE x VIA date` for temporal axes.
- `FROM` sets domain, `TO` sets range or palette, `SETTING` supplies extras like tick spacing.

## FACET Clause

```
FACET vars
FACET row_vars BY col_vars
  SETTING free => ('x', 'y'), ncol => 3, spacing => 12
```

- Wrap layout: single list of variables (auto wrap).
- Grid layout: use `BY` to specify row and column variables.
- Set `free` to `'x'`, `'y'`, or `('x','y')` for independent axes.
- Rename facet labels via `SCALE panel RENAMING ...`.

## PROJECT Clause

```
PROJECT [aesthetic, ...] TO cartesian|polar
  SETTING clip => true
```

- Default aesthetics: `x, y` for cartesian; `angle, radius` for polar.
- Swap aesthetics (`PROJECT y, x TO cartesian`) to flip axes.
- Use polar for pies/rose charts; combine with `DRAW area` or `DRAW arc`.

## LABEL Clause

```
LABEL title => 'Title', subtitle => 'Subtitle',
      x => 'X Axis', y => 'Y Axis', caption => 'Caption'
```

- Accepts `title`, `subtitle`, `caption`, `tag`, and any aesthetic label.

## Inspecting Queries

- `validate(query)` checks structure and returns SQL/VISUALISE segments.
- `reader.execute(query)` returns a `Spec` with resolved layers, metadata, and warnings.

## Useful Notes

- The Oracle adapter works with Polars DataFrames; categorical outputs are cast to strings.
- `ggsqlOracle.sync()` stores the last executed SQL; `plot()` renders with Altair.
- For multi-layer charts, ensure required columns are present in the SQL result before `VISUALISE` clauses.
- Use `VISUALISE FROM` for CTEs or temporary tables produced in SQLcl.
