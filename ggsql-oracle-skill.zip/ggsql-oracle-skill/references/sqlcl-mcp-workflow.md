# SQLcl MCP Workflow

Use the SQLcl MCP server skill before running `ggsqlOracle.sync()` so you always feed confirmed SQL into ggsql.

## Connect and Inspect

1. Launch the SQLcl MCP server skill.
2. If a session is not active, run `CONNECT user/password@dsn` (or use a saved alias) to open Oracle.
3. Confirm which connection is active with `SHOW CONNECTION`. Use `HELP` to review other supported commands.
4. List saved aliases with `HELP ALIAS` or `ALIAS LIST` (depending on workspace setup). Many teams keep their SQLcl aliases in `~/.sqlcl/aliases.xml`.

> Tip: If your MCP server exposes a dedicated `listConnections` action, call it to enumerate available pooled connections before connecting manually.

## Validate SQL

- Run exploratory `SELECT` statements in SQLcl to make sure the query returns the expected columns and row counts.
- Capture any parameter values or predicates that need to be locked before passing the SQL to ggsql.
- Use Oracle-specific helpers such as `DESCRIBE <table>` and `INFO <view>` to check schemas.

## Stage SQL for ggsqlOracle

1. Once the SQL returns the desired result set in SQLcl, copy it verbatim into your Python workflow.
2. Prefer formatting large statements with common-table expressions (CTEs) so they remain readable inside the `sync()` call.
3. Make sure the SQL selects every column referenced later in the `VISUALISE` clause.

## Troubleshooting

- If `SHOW CONNECTION` reports `Not connected`, reconnect with the right wallet/tnsnames parameters and retry your validation query.
- Use `SET SQLFORMAT ansiconsole` for legible tabular feedback while iterating.
- Keep an eye on bind variables; expand them with `VARIABLE` assignments before reusing the SQL string in Python.
