# Oracle Python Environment Checklist

Use this when setting up a Python runtime for ggsql + Oracle.

## Create or Reuse a Virtual Environment

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r assets/requirements.txt
```

- The bundled `assets/requirements.txt` matches the ggsql blog environment (Altair, Polars, ggsql, oracledb, Jupyter tooling).
- If a workspace already has a virtual environment, activate it instead of creating a new one.

## Oracle Instant Client / Wallet

- Ensure the Oracle Instant Client libraries are available on the machine (`DYLD_LIBRARY_PATH` or `LD_LIBRARY_PATH` on macOS/Linux).
- If you need an Autonomous Database wallet, keep `tnsnames.ora` and `sqlnet.ora` in the folder referenced by `config_dir`.
- Store wallet credentials securely; avoid committing them alongside this skill.

## oracledb Connector Modes

- **Thin mode** (default) works for most cloud databases; no Instant Client needed if wallet is supplied.
- **Thick mode** requires `oracledb.init_oracle_client(lib_dir=...)`; use when advanced features or FAN notifications are needed.
- Toggle modes early in your script before constructing connections or pools.

## Environment Variables Worth Checking

| Variable | Purpose |
| --- | --- |
| `TNS_ADMIN` | Directory containing wallet/tnsnames files. |
| `LD_LIBRARY_PATH` / `DYLD_LIBRARY_PATH` | Oracle Client library search path. |
| `PATH` | Should include Instant Client binaries when using thick mode. |
| `SQLCL_ALIAS_PATH` | Optional; where SQLcl looks for alias definitions. |

## Connection Security

- Keep secrets (usernames, passwords, DSNs, wallet passwords) in `.env` files or secret managers.
- When you must load credentials from JSON (see example script), read with `Path(...).read_text()` and avoid printing them to logs.

## Verification Steps

1. Activate the environment and run `python -c "import ggsql, polars, oracledb"` to ensure dependencies import cleanly.
2. Run a smoke query with SQLcl (`SELECT 1 FROM dual`) before switching to Python.
3. Execute the example script (`python examples/oracle_violin.py`) after editing connection parameters to confirm ggsql + Altair rendering works.
